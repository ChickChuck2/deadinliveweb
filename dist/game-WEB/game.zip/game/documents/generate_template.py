from docx import Document
from docx.shared import Pt
from docx.enum.text import WD_ALIGN_PARAGRAPH
import os

def create_template(path):
    doc = Document()
    
    # Title
    title = doc.add_heading('Guia de Escrita: Modelo de Cena (Template)', 0)
    title.alignment = WD_ALIGN_PARAGRAPH.CENTER
    
    # Introduction
    doc.add_heading('1. Como Organizar suas Cenas', level=1)
    doc.add_paragraph('Para manter o projeto "Dead in Live" organizado e facilitar a implementação no Ren\'Py, siga este modelo para cada nova cena ou capítulo.')
    
    doc.add_heading('Elementos Essenciais:', level=2)
    doc.add_paragraph('Fundo (BG): Especifique a imagem de fundo no início de cada mudança de local.', style='List Bullet')
    doc.add_paragraph('Música/Som: Indique quando uma música deve começar, parar ou quando um efeito sonoro (SFX) deve tocar.', style='List Bullet')
    doc.add_paragraph('Atores (Personagens): Mencione quais personagens aparecem na tela e qual sua expressão.', style='List Bullet')
    doc.add_paragraph('Escolhas: Sempre use tópicos para escolhas e identifique as consequências de cada uma.', style='List Bullet')

    doc.add_page_break()

    # The Template Section
    doc.add_heading('2. Modelo de Escrita (Copie este bloco)', level=1)
    
    doc.add_heading('--- [NOME DA CENA] ---', level=2)
    
    p = doc.add_paragraph()
    p.add_run('Configuração Inicial:').bold = True
    doc.add_paragraph('• Fundo: [Nome do BG]')
    doc.add_paragraph('• Música: [Nome da BGM]')
    doc.add_paragraph('• Personagem em cena: [Nome e Expressão]')

    doc.add_heading('DIÁLOGO / NARRAÇÃO', level=3)
    doc.add_paragraph('[PERSONAGEM]: "Escreva sua fala aqui entre aspas."')
    doc.add_paragraph('NARRAÇÃO: Escreva descrições ou pensamentos internos aqui.', style='Body Text')

    doc.add_heading('SISTEMA DE ESCOLHAS', level=3)
    doc.add_paragraph('MENU: [Pergunta que aparece para o jogador]')
    
    doc.add_paragraph('Opção A: [Texto da Escolha]', style='List Bullet')
    doc.add_paragraph('   > Consequência: [O que acontece se escolher A]')
    
    doc.add_paragraph('Opção B: [Texto da Escolha]', style='List Bullet')
    doc.add_paragraph('   > Consequência: [O que acontece se escolher B]')

    doc.add_heading('NOTAS PARA O PROGRAMADOR', level=3)
    doc.add_paragraph('[Ex: Aqui a felicidade deve subir +5. Mudar o fundo para preto por 2 segundos.]')

    doc.save(path)

if __name__ == "__main__":
    folder = "documents/story"
    if not os.path.exists(folder):
        try:
            os.makedirs(folder)
        except:
            pass
    
    try:
        create_template(os.path.join(folder, "Cena_DEMO.docx"))
        print("Modelo Cena_DEMO.docx gerado com sucesso!")
    except Exception as e:
        print(f"Erro ao gerar documento: {e}")
