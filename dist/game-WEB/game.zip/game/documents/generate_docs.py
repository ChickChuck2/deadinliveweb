from docx import Document
from docx.shared import Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
import os

def create_prologue(path):
    doc = Document()
    
    # Title
    title = doc.add_heading('Dead in Live - Roteiro', 0)
    title.alignment = WD_ALIGN_PARAGRAPH.CENTER
    
    doc.add_heading('Prólogo: Memórias (Prologue_01)', level=1)
    
    doc.add_paragraph('---', style='Caption')
    
    # Scene 1
    doc.add_heading('Cena: O Parque (Passado)', level=2)
    p = doc.add_paragraph()
    p.add_run('Fundo: ').bold = True
    p.add_run('bg park (Dia ensolarado)')
    
    p = doc.add_paragraph()
    p.add_run('Música: ').bold = True
    p.add_run('bg_music_1')
    
    doc.add_heading('NARRAÇÃO:', level=3)
    doc.add_paragraph('Um dia ensolarado no parque. Eu me lembro bem... A minha infância... foi tão feliz quando eu era pequena. Ao menos nos primeiros anos, quando eu não entendia nada.')
    
    doc.add_paragraph('(Aparece Leah criança - 4 anos de idade)', style='Caption')
    
    doc.add_heading('NARRAÇÃO:', level=3)
    doc.add_paragraph('Eu adorava conhecer novas pessoas e fazer amigos. Nesse dia eu estava no parque brincando sozinha quando vi umas crianças brincando juntas. Eu vi de longe uma pequena menina que parecia muito legal e divertida.')
    
    doc.add_heading('ESCOLHA DO JOGADOR:', level=2)
    list_item = doc.add_paragraph('Aproximar-se dela:', style='List Bullet')
    doc.add_paragraph('(Aparece Maya criança)', style='Caption')
    doc.add_paragraph('LEAH: "Oi! Posso brincar com você?"')
    doc.add_paragraph('MAYA: "Claro!"')
    
    list_item = doc.add_paragraph('Ficar onde estava:', style='List Bullet')
    doc.add_paragraph('(Maya percebe Leah e se aproxima)', style='Caption')
    doc.add_paragraph('MAYA: "Oi! Quer brincar comigo?"')
    doc.add_paragraph('LEAH: "Claro!"')
    
    doc.add_heading('Encontro com Maya', level=2)
    doc.add_heading('NARRAÇÃO:', level=3)
    doc.add_paragraph('Foi nesse parque que conheci minha melhor amiga, Maya. Uma menina alegre e divertida, adorava as mesmas coisas que eu. Me lembro até hoje do apelido que ela me deu.')
    
    doc.add_paragraph('MAYA: "Oi menina do cabelo de uva! Quer brincar comigo? Eu gostei do seu cabelo, é tão colorido! E sua roupa é parecida com a minha."')
    doc.add_paragraph('LEAH: "Cabelo de uva? Sério? Sorte sua que é uma das minhas frutas favoritas! Quer brincar de esconde-esconde?"')
    doc.add_paragraph('MAYA: "Vamos! Eu sou profissional nisso!"')
    
    doc.add_paragraph('(Brincadeira de esconde-esconde acontece)', style='Caption')
    
    doc.add_paragraph('MAYA: "Onde você está, Leah?"')
    doc.add_paragraph('LEAH: "Hehe, você não vai me encontrar tão fácil!"')
    
    doc.add_heading('O Fim da Inocência (6-7 anos)', level=2)
    doc.add_heading('NARRAÇÃO:', level=3)
    doc.add_paragraph('Aos meus 6 anos de idade meus gostos por desenhos animados mudaram. Dessa vez eu gostava de temas de monstrinhos e de dia das bruxas. Costumava tirar notas boas na escola e meus pais sempre elogiavam meu desempenho. "Menina inteligente e dedicada", eles diziam. Eu amava meus pais, e meu pior medo era decepcioná-los. Na verdade... Decepcionar minha mãe. Apesar dos meus medos e pesadelos eu escondia eles de mim mesmo pois pensava "Quando eu crescer isso vai passar".')
    
    p = doc.add_paragraph()
    p.add_run('Fundo: ').bold = True
    p.add_run('bg dark_park (Clima pesado)')
    
    doc.add_heading('NARRAÇÃO:', level=3)
    doc.add_paragraph('Quando meu aniversário de 7 anos chegou, poucos dias antes meus pais haviam brigado. Minha mãe estava com hematomas que escondia com maquiagem e sorrisos falsos para não me preocupar. Ela dizia que tinha tropeçado, mas eu ouvia ela gritar. Meu pai sustentava tudo sem reclamar, mas não significava que ele se importava com a gente. Ele se forçava a ter obrigações comigo pelo simples fato de ele me ter gerado. Como um fardo.')
    
    doc.add_heading('CLÍMAX EMOCIONAL:', level=2)
    doc.add_paragraph('• "Eu não sabia o que fazer, para onde ir..."')
    doc.add_paragraph('• "Eu só queria fugir daquela situação."')
    doc.add_paragraph('• "Eu me sentia tão perdida e sozinha e vazia..."')
    doc.add_paragraph('• "Eu não conseguia entender por que isso estava acontecendo comigo, com minha mãe..."')
    doc.add_paragraph('• "Eu só queria que tudo aquilo acabasse..."')
    
    doc.add_paragraph('Fundo: black', style='Caption')
    doc.add_paragraph('"Te restou pouco da sua sanidade mental. Sua infância foi repleta de traumas e abusos psicológicos. Tome cuidado."', style='Quote')
    
    doc.save(path)

def create_chapter_1(path):
    doc = Document()
    
    title = doc.add_heading('Dead in Live - Roteiro', 0)
    title.alignment = WD_ALIGN_PARAGRAPH.CENTER
    
    doc.add_heading('Capítulo 1: O Despertar (Chapter_01)', level=1)
    
    doc.add_paragraph('---', style='Caption')
    
    # Scene: Quarto
    doc.add_heading('Cena: Quarto da Leah', level=2)
    p = doc.add_paragraph()
    p.add_run('Fundo: ').bold = True
    p.add_run('bg leah_room')
    
    p = doc.add_paragraph()
    p.add_run('Som: ').bold = True
    p.add_run('alarme.mp3 (loop)')
    
    doc.add_paragraph('LEAH: "Sonhei com minha infância novamente... Esses sonhos sempre me deixam tão pensativa... Mas eu preciso me levantar agora. Já passei tempo demais na cama."')
    
    doc.add_paragraph('(O alarme para)', style='Caption')
    doc.add_paragraph('LEAH: "Agora preciso me arrumar para ir à escola. Mas meu quarto está uma bagunça..."')
    
    doc.add_heading('ESCOLHA DO JOGADOR:', level=2)
    doc.add_paragraph('Arrumar o quarto:', style='List Bullet')
    doc.add_paragraph('LEAH: "Melhor eu arrumar meu quarto antes de sair. Mamãe gosta dele arrumado. Assim eu volto para um lugar organizado e bonito."')
    doc.add_paragraph('(Chance de encontrar fotos antigas e recordar momentos felizes)', style='Caption')
    
    doc.add_paragraph('Não arrumar o quarto:', style='List Bullet')
    doc.add_paragraph('LEAH: "Não tenho tempo para arrumar meu quarto agora. Não é importante. Melhor eu me arrumar logo."')
    
    doc.add_heading('Cena: Encontro com a Mãe', level=2)
    doc.add_paragraph('(*TOC TOC*)', style='Caption')
    doc.add_paragraph('LEAH: "Quem será a essa hora? Quem é?"')
    doc.add_paragraph('MÃE (MADALENA): "Sou eu, posso entrar?"')
    doc.add_paragraph('LEAH: "Claro mãe, entre."')
    
    doc.add_paragraph('MADALENA: "Bom dia querida, vejo que você [arrumou/não arrumou] seu quarto hoje. Espero que você tenha um bom dia na escola. Vai comer alguma coisa antes de sair?"')
    
    doc.add_heading('ESCOLHA DO JOGADOR:', level=2)
    doc.add_paragraph('Comer algo:', style='List Bullet')
    doc.add_paragraph('LEAH: "Sim, estou um pouco atrasada, mas a fome é maior."')
    doc.add_paragraph('MADALENA: "Ótimo, você precisa se alimentar bem para ter energia. Vamos na cozinha então."')
    
    doc.add_paragraph('Não comer nada:', style='List Bullet')
    doc.add_paragraph('LEAH: "Não, obrigada mãe. Estou com pressa hoje."')
    doc.add_paragraph('MADALENA: "Tudo bem filha, mas não se esqueça de comer algo mais tarde. Faz dias que você não come direito, me preocupo com sua saúde."')
    
    doc.add_heading('Cena: A Cozinha', level=2)
    p = doc.add_paragraph()
    p.add_run('Fundo: ').bold = True
    p.add_run('bg cozinha')
    
    doc.add_paragraph('NARRAÇÃO: Enquanto isso, meu pai chegou na cozinha. Sem dizer uma palavra.')
    doc.add_paragraph('PAI (DEMETRIUS): "Querida, poderia fazer um café para mim?"')
    doc.add_paragraph('MADALENA: "Claro, só vou fazer algo para a Leah rapidinho, pois ela está com pressa."')
    doc.add_paragraph('DEMETRIUS: "Não foi uma pergunta, faça o café enquanto eu vejo as notícias, seja rápida."')
    
    doc.add_paragraph('NARRAÇÃO: Meu pai sempre foi assim, mandão e rude. Um verdadeiro merda.')
    
    doc.add_paragraph('LEAH (Sussurrando): "Tomara que tenha veneno..."')
    
    doc.add_heading('Cena: Indo para a Escola', level=2)
    p = doc.add_paragraph()
    p.add_run('Fundo: ').bold = True
    p.add_run('bg esquina')
    doc.add_paragraph('LEAH: "Droga! Estou atrasada! Melhor eu correr para não perder o ônibus."')
    
    doc.add_paragraph('---', style='Caption')
    doc.add_paragraph('Fim do Capítulo 1', style='Subtitle')
    
    doc.save(path)

if __name__ == "__main__":
    folder = "documents/story"
    if not os.path.exists(folder):
        os.makedirs(folder)
    
    create_prologue(os.path.join(folder, "Prologue_01.docx"))
    create_chapter_1(os.path.join(folder, "Chapter_01.docx"))
    print("Documentos Word gerados com sucesso!")
